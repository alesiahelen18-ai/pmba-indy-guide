# PMBA Indy Guide

Static single-page app for the Physician MBA Indy residency.
Deployed via GitHub Pages from the root of the default branch.
